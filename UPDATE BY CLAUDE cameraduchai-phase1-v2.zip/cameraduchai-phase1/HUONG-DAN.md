# Giai đoạn 1 (bản 2) – Tăng tốc cameraduchai

Dựa trên Archive.zip mới nhất của bạn (có đơn nhập hàng, PurchasePayment, upload ảnh Supabase).
Các file nằm đúng đường dẫn như trong dự án: mở từng file, Ctrl+A, Ctrl+C, rồi dán đè vào file cùng đường dẫn.
File ghi MỚI thì tạo file mới. Bản này thay thế hoàn toàn bản zip trước, nếu đã chép bản cũ thì chép đè lại các file bên dưới.

## Danh sách 24 file

| Nhóm | Đường dẫn | Việc làm |
|---|---|---|
| Nền tảng | prisma/schema.prisma | Thay toàn bộ (thêm index, bật relationJoins) |
| | prisma/migrations/20261024000000_add_perf_indexes/migration.sql | MỚI |
| | src/lib/prisma.ts | Thay toàn bộ (bỏ ép connection_limit=1) |
| | src/lib/date.ts | MỚI (tính ngày theo giờ Việt Nam) |
| | src/lib/auth.ts | Thay toàn bộ (chỉ bỏ console.log, logic y nguyên) |
| Giao diện | src/lib/settings-context.tsx | MỚI (gọi /api/settings 1 lần) |
| | src/app/providers.tsx | Thay toàn bộ |
| | src/app/layout.tsx | Thay toàn bộ |
| | src/components/shared/PageTitle.tsx | Thay toàn bộ |
| | src/components/layout/Sidebar.tsx | Thay toàn bộ |
| | src/components/layout/MobileMenu.tsx | Thay toàn bộ |
| API | src/app/api/settings/route.ts | Thay toàn bộ (cache 30 giây) |
| | src/app/api/dashboard/route.ts | Thay toàn bộ (SQL tổng hợp) |
| | src/app/api/sales/route.ts | Thay toàn bộ |
| | src/app/api/sales/[id]/route.ts | Thay toàn bộ |
| | src/app/api/products/route.ts | Thay toàn bộ |
| | src/app/api/reports/revenue/route.ts | Thay toàn bộ |
| | src/app/api/reports/profit/route.ts | Thay toàn bộ |
| | src/app/api/reports/stock/route.ts | Thay toàn bộ |
| | src/app/api/purchase-orders/route.ts | Thay toàn bộ (MỚI so với bản 1) |
| | src/app/api/purchase-orders/[id]/route.ts | Thay toàn bộ (MỚI so với bản 1) |
| | src/app/api/import/products/route.ts | Thay toàn bộ (MỚI so với bản 1) |
| | src/app/api/warranties/route.ts | Thay toàn bộ (MỚI so với bản 1) |
| | src/app/api/audit-logs/route.ts | Thay toàn bộ (MỚI so với bản 1) |

## Thứ tự triển khai
1. Sao lưu dữ liệu (trang Backup trong app, hoặc Supabase > Database > Backups).
2. Chạy nội dung migration.sql trong Supabase > SQL Editor (chạy lại nhiều lần không sao).
   Sau đó trên máy bạn nhớ chạy `npx prisma migrate resolve --applied 20261024000000_add_perf_indexes`
   để Prisma biết migration này đã được áp dụng (nếu bỏ qua, lần `prisma migrate deploy` sau sẽ chạy lại, cũng không lỗi vì có IF NOT EXISTS).
3. Chép các file vào dự án.
4. `npm install` (tự chạy prisma generate), rồi `npx tsc --noEmit`.
   Có sẵn khoảng 19 lỗi kiểu của code cũ (ô Select ở vài trang, prisma/seed.ts); các file trong gói này không thêm lỗi nào.
5. `npm run dev` và thử theo danh sách bên dưới.
6. `git add . && git commit -m "perf: phase 1" && git push` để Netlify tự deploy.

## Thử trước khi đưa lên
- Tổng quan: số liệu hôm nay/tháng, top 5, sắp hết hàng, đơn gần đây
- Đơn hàng: lọc theo ngày, theo trạng thái thanh toán, tìm theo mã/tên/SĐT; mở chi tiết một đơn; thu nốt tiền một đơn
- Tạo đơn bán: (a) SP thường, (b) SP có serial (kiểm tra bảo hành được tạo), (c) bán thiếu hàng phải báo lỗi, (d) khách ghi nợ
- Đơn nhập: tạo phiếu có serial và có ảnh chứng từ, trả trước một phần; danh sách phiếu nhập; mở chi tiết; "Thanh toán đủ"
- Import sản phẩm bằng Excel: file có dòng mới, dòng cập nhật, dòng lỗi (vd tồn kho 2,5) → báo đúng số tạo/cập nhật/lỗi
- Xuất Excel đơn hàng (Import/Export), báo cáo doanh thu và lợi nhuận, trang bảo hành, nhật ký (lọc theo ngày)
- Đổi tên cửa hàng ở Cài đặt, F5: tên trên menu và tiêu đề tab đổi theo

## Biến môi trường tuỳ chọn (Netlify)
- DB_POOL_SIZE (mặc định 5): số kết nối mỗi function.

## Thay đổi hành vi cần biết
- GET /api/sales: tối đa 100 đơn mới nhất (xuất Excel vẫn lấy được 10.000), không còn kèm danh sách items.
- GET /api/purchase-orders: tối đa 200 phiếu mới nhất, không còn kèm chi tiết sản phẩm/serial (trang danh sách không dùng).
- Ngày lọc/báo cáo/nhật ký tính theo giờ Việt Nam (trước đây theo UTC nên lệch 7 tiếng).
- "Sắp hết hàng" ở Tổng quan là số đếm thật (trước đây tối đa 10).
- Bán hàng: kiểm tra serial thuộc đúng sản phẩm; trừ kho có điều kiện chống bán vượt tồn.
- Import sản phẩm: cột số nguyên (tồn kho, tồn tối thiểu, bảo hành) phải là số nguyên, nếu không dòng đó báo lỗi. Các dòng trùng SKU trong cùng file: dòng sau ghi đè dòng trước.
- Phiếu nhập: bấm thanh toán khi đã trả đủ sẽ báo "Đã thanh toán đủ" thay vì ghi thêm dòng 0đ.
